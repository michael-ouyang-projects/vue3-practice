<template>
  Declarative Rendering(text): <br/>
  {{ message }}<br/><br/>

  Declarative Rendering (attributes): <br/>
  <div v-bind:style="myStyle">{{ message }}</div>
  <div :style="myStyle">{{ message }}</div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'DeclarativeRendering',
  setup () {
    // text
    const message = 'Hello Vue!'

    // attributes
    const myStyle = 'color: red'

    return {
      message,
      myStyle
    }
  }
})
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
