<template>
  <div class="title">Conditionals(F12-Elements): </div>
  {{ seen }}
  <div v-if="seen">== IF ==</div>
  <div v-show="seen">== SHOW ==</div>
  <button @click="toggle()">toggle</button><br/><br/>

  <div class="title">Loops: </div>
  <div v-for="customer in customers" :key="customer.name">
    {{ customer.name }}
  </div><br/>

  <div class="title">:key </div>
  <table>
    <tr v-for="(customer, index) in customers" :key="customer.name">
      <td>{{ index }}: {{ customer.name }}, {{ customer.age }}</td>
      <td><input type="text" /></td>
      <td><button @click="removeFromList(index)">remove</button></td>
    </tr>
  </table><br/>
  <button @click="reset">Reset</button><br/>
</template>

<script lang="ts">
import { defineComponent, Ref, ref } from 'vue'

export default defineComponent({
  name: 'ConditionalsAndLoops',
  setup () {
    // Conditionals
    const seen: Ref<boolean> = ref(true)
    const toggle = (): void => {
      seen.value = !seen.value
    }

    // Loops
    const customers = ref([
      { name: 'Amy', age: 21 },
      { name: 'Bob', age: 21 },
      { name: 'Charlie', age: 24 }
    ])

    // :key
    const removeFromList = (index: number) => {
      customers.value.splice(index, 1)
    }
    const reset = () => {
      customers.value = [
        { name: 'Amy', age: 21 },
        { name: 'Bob', age: 21 },
        { name: 'Charlie', age: 24 }]
    }

    return {
      seen,
      toggle,
      customers,
      removeFromList,
      reset
    }
  }
})
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}

table {
  margin-left: auto;
  margin-right: auto;
  border-spacing: 0px;
}

th, td {
  padding: 15px;
  border-bottom: 1px solid black;
}
</style>
