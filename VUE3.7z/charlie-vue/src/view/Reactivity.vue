<template>
  <div class="title">Reactivity vs Non-Reactivity(F12): </div>
  message: {{ message }}<br/>
  refMessage: {{ refMessage }}<br/>
  <button @click="changeMessage()">Click</button><br/><br/>

  <div class="title">reactive vs ref(F12): </div>
  {{ customerName }}<br/>
  <input v-model="customerName" /><br/>
  {{ customerB.name }}<br/>
  <input v-model="customerB.name" /><br/>
</template>

<script lang="ts">
import { defineComponent, Ref, ref, reactive } from 'vue'

export default defineComponent({
  name: 'Reactivity',
  setup () {
    // Reactivity vs Non-Reactivity
    let message = 'Hello Vue!'
    const refMessage: Ref<string> = ref('Hello Vue!')
    const changeMessage = (): void => {
      message = 'Hello Charlie!'
      refMessage.value = 'Hello Charlie!'
      console.log('message: ' + message)
      console.log('refMessage: ' + refMessage.value)
    }

    // reactive
    const customerA = { name: 'none' }
    const customerB = reactive({ name: 'reactive' })
    console.log(customerA)
    console.log(customerB)

    // ref
    const customerName = ref('ref')
    const customer = ref({ name: 'ref' })
    console.log(customerName)
    console.log(customer)

    return {
      message,
      refMessage,
      changeMessage,
      customerName,
      customerB
    }
  }
})
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
