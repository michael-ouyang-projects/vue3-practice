<template>
  <div class="title">Click: </div>
  {{ message }}
  <button v-on:click="changeMessage()">Click</button>&nbsp;
  <button @click="resetMessage()">Reset</button><br/><br/>

  <div class="title">Mouse: </div>
  <button @mouseover="changeTextWhenOver()"
          @mouseleave="changeTextWhenLeave()">{{ text }}</button><br/><br/>

  <div class="title">Two-Way Binding: </div>
  {{ data }}
  <input v-model="data" /><br/><br/>

  <div class="title">Change: </div>
  <select v-model="rows" @change="changeRows()">
    <option value="5">5</option>
    <option value="10">10</option>
    <option value="20">20</option>
    <option value="50">50</option>
  </select><br/>
</template>

<script lang="ts">
import { defineComponent, Ref, ref } from 'vue'

export default defineComponent({
  name: 'EventHandling',
  setup () {
    // Click Event
    const message: Ref<string> = ref('Hello Vue!')
    const changeMessage = (): void => {
      message.value = 'Hello Charlie!'
    }
    const resetMessage = (): void => {
      message.value = 'Hello Vue!'
    }

    // Mouse Event
    const text: Ref<string> = ref('Hello Vue!')
    const changeTextWhenOver = (): void => {
      text.value = 'Hello Charlie!'
    }
    const changeTextWhenLeave = (): void => {
      text.value = 'Hello Vue!'
    }

    // Two-Way Binding
    const data: Ref<string> = ref('123...')

    // Change
    const rows: Ref<string> = ref('5')
    const changeRows = (): void => {
      alert(rows.value)
    }

    return {
      message,
      changeMessage,
      resetMessage,
      text,
      changeTextWhenOver,
      changeTextWhenLeave,
      data,
      rows,
      changeRows
    }
  }
})
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
