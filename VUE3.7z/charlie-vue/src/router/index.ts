import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router'
import HelloWorld from '@/components/HelloWorld.vue' // @ is an alias to /src
import DeclarativeRendering from '@/view/DeclarativeRendering.vue'
import EventHandling from '@/view/EventHandling.vue'
import Reactivity from '@/view/Reactivity.vue'
import ConditionalsAndLoops from '@/view/ConditionalsAndLoops.vue'

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    name: 'HelloWorld',
    component: HelloWorld
  },
  {
    path: '/declarative-rendering',
    name: 'DeclarativeRendering',
    component: DeclarativeRendering
  },
  {
    path: '/event-handling',
    name: 'EventHandling',
    component: EventHandling
  },
  {
    path: '/reactivity',
    name: 'Reactivity',
    component: Reactivity
  },
  {
    path: '/conditionals-and-loops',
    name: 'ConditionalsAndLoops',
    component: ConditionalsAndLoops
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
